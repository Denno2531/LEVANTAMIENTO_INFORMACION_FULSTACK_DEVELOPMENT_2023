$(document).ready(function() {
    $('.select-careers-teachers').select2();
});