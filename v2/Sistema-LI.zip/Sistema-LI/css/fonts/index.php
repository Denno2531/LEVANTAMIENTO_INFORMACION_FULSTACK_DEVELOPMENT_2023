<?php
header('Location: /');
exit();