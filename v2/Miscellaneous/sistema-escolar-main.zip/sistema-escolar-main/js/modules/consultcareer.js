/*-------------------------------------------
  consultcareer.js
  By Diego Carmona Bernal - CBDX
  www.diegocarmonabernal.com
  www.mysoftup.com
-------------------------------------------*/

$(document).ready(function() {
    $('.select-careers-teachers').select2();
});